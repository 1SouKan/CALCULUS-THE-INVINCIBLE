library(shiny)
 
 # Функция shinyServer() определяет логику отображения элементов
 # графического интерфейса и обновления значений различных переменных:
 shinyServer(function(input, output) {
 
})


